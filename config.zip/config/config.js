const config = {
    "dev-mode": true
}

module.exports = config;